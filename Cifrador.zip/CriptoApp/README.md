# CriptoApp - algoritmos tradicionales separados por archivos

Esta versión mantiene la misma interfaz (`app.py`), pero separa la lógica de cifrado y descifrado para que sea más fácil probar, modificar y explicar cada algoritmo.

## Estructura principal

```text
app.py
crypto_algorithms.py
algoritmos encriptacion/
  aes.py
  des.py
  rc4.py
  cesar.py
  vigenere.py
algoritmos desencriptacion/
  aes.py
  des.py
  rc4.py
  cesar.py
  vigenere.py
almacenamiento_archivos/
  archivos_encriptados/
requirements.txt
test_crypto.py
```

`crypto_algorithms.py` es solo el coordinador: empaqueta el archivo `.encfile`, guarda el encabezado, verifica el HMAC y llama al archivo del algoritmo correspondiente.

## Algoritmos

- César: desplazamiento clásico de 0 a 255 sobre bytes.
- Vigenère: contraseña repetida directamente sobre bytes.
- DES: DES-CBC con clave directa de 8 bytes.
- RC4: RC4 clásico con clave directa.
- AES: AES-128-CBC con clave directa de 16 bytes.

No se usa PBKDF2 ni derivación fuerte de claves, porque el objetivo del proyecto es que sean algoritmos tradicionales y atacables.

## Ejecutar

```bat
py -m pip install -r requirements.txt
py app.py
```

## Probar

```bat
py test_crypto.py
```

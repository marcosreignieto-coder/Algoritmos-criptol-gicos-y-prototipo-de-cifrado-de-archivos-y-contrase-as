"""Aplicación con interfaz gráfica para cifrar y descifrar imágenes y archivos de texto.

Ejecución:
    python app.py
"""

from __future__ import annotations

import os
import sys
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from crypto_algorithms import CryptoError, available_algorithms, decrypt_file, encrypt_file

BASE_DIR = Path(__file__).resolve().parent
STORAGE_DIR = BASE_DIR / "almacenamiento_archivos"
ENCRYPTED_DIR = STORAGE_DIR / "archivos_encriptados"
DECRYPTED_DIR = STORAGE_DIR / "archivos_desencriptados"
ICON_PATH = BASE_DIR / "app_icon.ico"

FILE_TYPES = (
    ("Imágenes y texto", "*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tiff *.txt *.md *.csv *.json *.xml *.py"),
    ("Textos", "*.txt *.md *.csv *.json *.xml *.py"),
    ("Imágenes", "*.png *.jpg *.jpeg *.bmp *.gif *.webp *.tiff"),
    ("Todos los archivos", "*.*"),
)

ENCRYPTED_TYPES = (
    ("Archivos cifrados", "*.encfile *.encimg"),
    ("Todos los archivos", "*.*"),
)


class CryptoFilesApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Cripto App - Cifrado de imágenes y textos")
        self.geometry("920x640")
        self.minsize(820, 560)
        self.configure(bg="#0f172a")

        if ICON_PATH.exists():
            try:
                self.iconbitmap(str(ICON_PATH))
            except tk.TclError:
                pass

        ENCRYPTED_DIR.mkdir(parents=True, exist_ok=True)
        DECRYPTED_DIR.mkdir(parents=True, exist_ok=True)

        self.file_path = tk.StringVar()
        self.encrypted_path = tk.StringVar()
        self.algorithm = tk.StringVar(value="AES")
        self.encrypt_output_name = tk.StringVar()
        self.status = tk.StringVar(value=f"Carpeta de almacenamiento: {STORAGE_DIR}")

        self._configure_style()
        self._build_ui()

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure("Main.TFrame", background="#0f172a")
        style.configure("Card.TFrame", background="#ffffff", relief="flat")
        style.configure("Title.TLabel", background="#0f172a", foreground="#e0f2fe", font=("Segoe UI", 24, "bold"))
        style.configure("Subtitle.TLabel", background="#0f172a", foreground="#bfdbfe", font=("Segoe UI", 11))
        style.configure("CardTitle.TLabel", background="#ffffff", foreground="#0f172a", font=("Segoe UI", 15, "bold"))
        style.configure("CardText.TLabel", background="#ffffff", foreground="#334155", font=("Segoe UI", 10))
        style.configure("TLabel", font=("Segoe UI", 10))
        style.configure("TEntry", padding=7)
        style.configure("TCombobox", padding=7)
        style.configure("Primary.TButton", font=("Segoe UI", 10, "bold"), padding=10)
        style.configure("Secondary.TButton", font=("Segoe UI", 10), padding=8)
        style.configure("Status.TLabel", background="#1e293b", foreground="#e2e8f0", padding=10, font=("Segoe UI", 9))
        style.configure("TNotebook", background="#0f172a", borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(20, 10))

    def _build_ui(self) -> None:
        main = ttk.Frame(self, style="Main.TFrame", padding=24)
        main.pack(fill="both", expand=True)

        ttk.Label(main, text="Cripto App", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            main,
            text="Cifra y descifra imágenes, textos y otros archivos con AES, DES, RC4, César o Vigenère.",
            style="Subtitle.TLabel",
            wraplength=840,
        ).pack(anchor="w", pady=(4, 18))

        stats = ttk.Frame(main, style="Main.TFrame")
        stats.pack(fill="x", pady=(0, 16))
        self._small_card(stats, "Algoritmos", "AES · DES · RC4 · César · Vigenère", 0)
        self._small_card(stats, "Entrada", "Imágenes, .txt y cualquier archivo", 1)
        self._small_card(stats, "Salida", "Carpeta automática de almacenamiento", 2)
        stats.columnconfigure((0, 1, 2), weight=1)

        notebook = ttk.Notebook(main)
        notebook.pack(fill="both", expand=True)

        encrypt_tab = ttk.Frame(notebook, padding=18)
        decrypt_tab = ttk.Frame(notebook, padding=18)
        notebook.add(encrypt_tab, text="🔒 Encriptar")
        notebook.add(decrypt_tab, text="🔓 Desencriptar")

        self._build_encrypt_tab(encrypt_tab)
        self._build_decrypt_tab(decrypt_tab)

        ttk.Label(main, textvariable=self.status, style="Status.TLabel", anchor="w").pack(fill="x", pady=(14, 0))

    def _small_card(self, parent: ttk.Frame, title: str, text: str, column: int) -> None:
        card = ttk.Frame(parent, style="Card.TFrame", padding=14)
        card.grid(row=0, column=column, sticky="ew", padx=6)
        ttk.Label(card, text=title, style="CardTitle.TLabel").pack(anchor="w")
        ttk.Label(card, text=text, style="CardText.TLabel", wraplength=240).pack(anchor="w", pady=(3, 0))

    def _build_encrypt_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(1, weight=1)
        ttk.Label(parent, text="Archivo original:").grid(row=0, column=0, sticky="w", pady=8)
        ttk.Entry(parent, textvariable=self.file_path).grid(row=0, column=1, sticky="ew", padx=10, pady=8)
        ttk.Button(parent, text="Buscar archivo", style="Secondary.TButton", command=self.select_file).grid(row=0, column=2, pady=8)

        ttk.Label(parent, text="Algoritmo:").grid(row=1, column=0, sticky="w", pady=8)
        algo = ttk.Combobox(parent, textvariable=self.algorithm, values=available_algorithms(), state="readonly", width=20)
        algo.grid(row=1, column=1, sticky="w", padx=10, pady=8)

        ttk.Label(parent, text="Contraseña:").grid(row=2, column=0, sticky="w", pady=8)
        self.encrypt_password = ttk.Entry(parent, show="*")
        self.encrypt_password.grid(row=2, column=1, sticky="ew", padx=10, pady=8)

        ttk.Label(parent, text="Nombre del archivo encriptado:").grid(row=3, column=0, sticky="w", pady=8)
        ttk.Entry(parent, textvariable=self.encrypt_output_name).grid(row=3, column=1, sticky="ew", padx=10, pady=8)

        ttk.Button(parent, text="Encriptar archivo", style="Primary.TButton", command=self.encrypt_action).grid(
            row=4, column=1, sticky="e", padx=10, pady=18
        )

        ttk.Label(
            parent,
            text=f"Los archivos cifrados se guardan automáticamente en:\n{ENCRYPTED_DIR}",
            wraplength=720,
        ).grid(row=5, column=0, columnspan=3, sticky="w", pady=12)

    def _build_decrypt_tab(self, parent: ttk.Frame) -> None:
        parent.columnconfigure(1, weight=1)
        ttk.Label(parent, text="Archivo cifrado:").grid(row=0, column=0, sticky="w", pady=8)
        ttk.Entry(parent, textvariable=self.encrypted_path).grid(row=0, column=1, sticky="ew", padx=10, pady=8)
        ttk.Button(parent, text="Buscar cifrado", style="Secondary.TButton", command=self.select_encrypted).grid(row=0, column=2, pady=8)

        ttk.Label(parent, text="Contraseña:").grid(row=1, column=0, sticky="w", pady=8)
        self.decrypt_password = ttk.Entry(parent, show="*")
        self.decrypt_password.grid(row=1, column=1, sticky="ew", padx=10, pady=8)

        ttk.Button(parent, text="Desencriptar archivo", style="Primary.TButton", command=self.decrypt_action).grid(
            row=2, column=1, sticky="e", padx=10, pady=18
        )

        ttk.Label(
            parent,
            text=f"Los archivos recuperados se guardan automáticamente en:\n{DECRYPTED_DIR}",
            wraplength=720,
        ).grid(row=3, column=0, columnspan=3, sticky="w", pady=12)

    def select_file(self) -> None:
        path = filedialog.askopenfilename(title="Selecciona un archivo", filetypes=FILE_TYPES)
        if path:
            self.file_path.set(path)
            self.encrypt_output_name.set(f"{Path(path).stem}_{self.algorithm.get()}")
            self.status.set(f"Archivo seleccionado: {path}")

    def select_encrypted(self) -> None:
        path = filedialog.askopenfilename(
            title="Selecciona un archivo cifrado",
            initialdir=ENCRYPTED_DIR if ENCRYPTED_DIR.exists() else BASE_DIR,
            filetypes=ENCRYPTED_TYPES,
        )
        if path:
            self.encrypted_path.set(path)
            self.status.set(f"Archivo cifrado seleccionado: {path}")

    def encrypt_action(self) -> None:
        try:
            output = encrypt_file(
                self.file_path.get(),
                self.encrypt_password.get(),
                self.algorithm.get(),
                ENCRYPTED_DIR,
                self.encrypt_output_name.get(),
            )
            self.status.set(f"Archivo encriptado correctamente: {output}")
            messagebox.showinfo("Éxito", f"Archivo encriptado correctamente:\n{output}")
        except CryptoError as exc:
            messagebox.showerror("Error", str(exc))
            self.status.set(f"Error: {exc}")
        except Exception as exc:  # pragma: no cover
            messagebox.showerror("Error inesperado", str(exc))
            self.status.set(f"Error inesperado: {exc}")

    def decrypt_action(self) -> None:
        try:
            output = decrypt_file(self.encrypted_path.get(), self.decrypt_password.get(), DECRYPTED_DIR)
            self.status.set(f"Archivo desencriptado correctamente: {output}")
            messagebox.showinfo("Éxito", f"Archivo desencriptado correctamente:\n{output}")
        except CryptoError as exc:
            messagebox.showerror("Error", str(exc))
            self.status.set(f"Error: {exc}")
        except Exception as exc:  # pragma: no cover
            messagebox.showerror("Error inesperado", str(exc))
            self.status.set(f"Error inesperado: {exc}")


if __name__ == "__main__":
    app = CryptoFilesApp()
    app.mainloop()

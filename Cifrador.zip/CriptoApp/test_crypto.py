from pathlib import Path
import tempfile

from crypto_algorithms import available_algorithms, decrypt_file, encrypt_file

PASSWORDS = {
    "AES": "clave-secreta",
    "DES": "desclave",
    "RC4": "clave-rc4",
    "CESAR": "73",
    "VIGNERE": "limon",
}

PNG_HEADER = bytes.fromhex("89504e470d0a1a0a0000000d49484452")


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        original = base / "mensaje.txt"
        original.write_text("Hola, esto es una prueba de cifrado de texto.", encoding="utf-8")
        enc_dir = base / "enc"
        dec_dir = base / "dec"

        for algorithm in available_algorithms():
            encrypted = encrypt_file(original, PASSWORDS[algorithm], algorithm, enc_dir)
            recovered = decrypt_file(encrypted, PASSWORDS[algorithm], dec_dir)
            assert recovered.read_bytes() == original.read_bytes(), algorithm
            print(f"OK {algorithm}: {encrypted.name} -> {recovered.name}")

        # Comprobación didáctica de Vigenère clásico sobre la cabecera PNG.
        key = b"limon"
        encrypted_header = bytes((b + key[i % len(key)]) % 256 for i, b in enumerate(PNG_HEADER))
        recovered_key_bytes = bytes((encrypted_header[i] - PNG_HEADER[i]) % 256 for i in range(len(key)))
        assert recovered_key_bytes == key
        print("OK VIGNERE: la cabecera PNG permite recuperar la clave corta.")

    print("Todas las pruebas han terminado correctamente.")


if __name__ == "__main__":
    main()

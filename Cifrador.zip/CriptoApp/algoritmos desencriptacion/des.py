"""Descifrado DES tradicional con clave directa de 8 bytes."""

from base64 import b64decode
from Crypto.Cipher import DES
from Crypto.Util.Padding import unpad


def _normalize_key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave DES no puede estar vacía.")
    raw = password.encode("utf-8")
    return raw[:8] if len(raw) >= 8 else raw + b"\x00" * (8 - len(raw))


def decrypt(ciphertext: bytes, password: str, header: dict) -> bytes:
    key = _normalize_key(password)
    iv = b64decode(header["iv"].encode("ascii"))
    cipher = DES.new(key, DES.MODE_CBC, iv=iv)
    try:
        return unpad(cipher.decrypt(ciphertext), DES.block_size)
    except ValueError as exc:
        raise ValueError("Contraseña incorrecta o datos DES dañados.") from exc

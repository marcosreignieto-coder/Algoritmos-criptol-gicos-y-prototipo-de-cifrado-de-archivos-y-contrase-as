"""Descifrado AES-128 tradicional con clave directa de 16 bytes."""

from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad


def _normalize_key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave AES no puede estar vacía.")
    raw = password.encode("utf-8")
    return raw[:16] if len(raw) >= 16 else raw + b"\x00" * (16 - len(raw))


def decrypt(ciphertext: bytes, password: str, header: dict) -> bytes:
    key = _normalize_key(password)
    iv = b64decode(header["iv"].encode("ascii"))
    cipher = AES.new(key, AES.MODE_CBC, iv=iv)
    try:
        return unpad(cipher.decrypt(ciphertext), AES.block_size)
    except ValueError as exc:
        raise ValueError("Contraseña incorrecta o datos AES dañados.") from exc

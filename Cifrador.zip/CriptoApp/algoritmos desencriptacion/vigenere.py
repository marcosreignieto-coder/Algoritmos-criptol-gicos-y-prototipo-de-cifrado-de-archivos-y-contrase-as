"""Descifrado Vigenère clásico sobre bytes."""


def _key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave Vigenère no puede estar vacía.")
    return password.encode("utf-8")


def decrypt(ciphertext: bytes, password: str, header: dict) -> bytes:
    key = _key(password)
    out = bytearray()
    for i, byte in enumerate(ciphertext):
        out.append((byte - key[i % len(key)]) % 256)
    return bytes(out)

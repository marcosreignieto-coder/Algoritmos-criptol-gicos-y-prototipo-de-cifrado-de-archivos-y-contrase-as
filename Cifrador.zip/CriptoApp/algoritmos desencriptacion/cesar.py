"""Descifrado César clásico sobre bytes."""


def _caesar_shift(password: str) -> int:
    text = (password or "").strip()
    if not text:
        raise ValueError("Para César introduce un desplazamiento entre 0 y 255.")
    try:
        shift = int(text)
    except ValueError as exc:
        raise ValueError("Para César la contraseña debe ser un número entre 0 y 255.") from exc
    if not 0 <= shift <= 255:
        raise ValueError("El desplazamiento César debe estar entre 0 y 255.")
    return shift


def decrypt(ciphertext: bytes, password: str, header: dict) -> bytes:
    shift = _caesar_shift(password)
    return bytes((byte - shift) % 256 for byte in ciphertext)

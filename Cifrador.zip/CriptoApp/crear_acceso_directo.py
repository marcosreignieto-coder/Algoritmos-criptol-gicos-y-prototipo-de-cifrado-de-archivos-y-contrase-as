"""Crea un acceso directo en el Escritorio para abrir la aplicación.

Ejecución:
    python crear_acceso_directo.py
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
APP = BASE_DIR / "app.py"
ICON = BASE_DIR / "app_icon.ico"
DESKTOP = Path(os.path.join(os.environ.get("USERPROFILE", str(Path.home())), "Desktop"))
SHORTCUT = DESKTOP / "Cripto App.lnk"
BAT = BASE_DIR / "abrir_cripto_app.bat"


def crear_bat() -> None:
    BAT.write_text(
        f'@echo off\ncd /d "{BASE_DIR}"\n"{sys.executable}" "{APP}"\n',
        encoding="utf-8",
    )


def crear_lnk_windows() -> bool:
    if os.name != "nt":
        return False
    crear_bat()
    ps_script = f"""
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut('{SHORTCUT}')
$Shortcut.TargetPath = '{BAT}'
$Shortcut.WorkingDirectory = '{BASE_DIR}'
$Shortcut.IconLocation = '{ICON}'
$Shortcut.Save()
"""
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_script],
        capture_output=True,
        text=True,
    )
    return completed.returncode == 0 and SHORTCUT.exists()


def main() -> None:
    DESKTOP.mkdir(parents=True, exist_ok=True)
    if crear_lnk_windows():
        print(f"Acceso directo creado en el Escritorio: {SHORTCUT}")
    else:
        crear_bat()
        fallback = DESKTOP / "Abrir Cripto App.bat"
        fallback.write_text(BAT.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"No se pudo crear .lnk. Se ha creado un lanzador alternativo: {fallback}")


if __name__ == "__main__":
    main()

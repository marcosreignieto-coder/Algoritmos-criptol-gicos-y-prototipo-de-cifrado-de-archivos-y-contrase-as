"""Coordinador de cifrado/descifrado de Cripto App.

Este archivo mantiene la API que usa la interfaz (`app.py`), pero la lógica de
cada algoritmo está separada en archivos individuales para poder probarlos y
modificarlos fácilmente.

Estructura:
- algoritmos encriptacion/aes.py, des.py, rc4.py, cesar.py, vigenere.py
- algoritmos desencriptacion/aes.py, des.py, rc4.py, cesar.py, vigenere.py

Los algoritmos son tradicionales/didácticos y no usan PBKDF2.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import importlib.util
import json
import struct
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, Tuple

MAGIC = b"CIMG1"
HEADER_LEN_SIZE = 4
KEY_MODE = "tradicional_didactico_sin_pbkdf2"
BASE_DIR = Path(__file__).resolve().parent
ENCRYPTION_DIR = BASE_DIR / "algoritmos encriptacion"
DECRYPTION_DIR = BASE_DIR / "algoritmos desencriptacion"


class CryptoError(Exception):
    """Error controlado de cifrado/descifrado."""


@dataclass(frozen=True)
class EncryptedPackage:
    header: dict
    ciphertext: bytes


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _load_function(folder: Path, file_name: str, function_name: str) -> Callable:
    module_path = folder / f"{file_name}.py"
    if not module_path.exists():
        raise CryptoError(f"No se encuentra el módulo del algoritmo: {module_path}")

    module_id = f"criptoapp_{folder.name.replace(' ', '_')}_{file_name}"
    spec = importlib.util.spec_from_file_location(module_id, module_path)
    if spec is None or spec.loader is None:
        raise CryptoError(f"No se pudo cargar el módulo: {module_path}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    try:
        return getattr(module, function_name)
    except AttributeError as exc:
        raise CryptoError(f"El archivo {module_path.name} no contiene la función {function_name}().") from exc


def _call_algorithm(func: Callable, *args):
    try:
        return func(*args)
    except CryptoError:
        raise
    except Exception as exc:
        raise CryptoError(str(exc)) from exc


def _make_mac(password: str, header_without_mac: dict, ciphertext: bytes) -> str:
    if password is None or password == "":
        raise CryptoError("La contraseña/clave no puede estar vacía.")
    auth_key = password.encode("utf-8")
    encoded_header = json.dumps(header_without_mac, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return _b64(hmac.new(auth_key, encoded_header + ciphertext, hashlib.sha256).digest())


def _check_mac(password: str, header: dict, ciphertext: bytes) -> None:
    expected = header.get("hmac")
    if not expected:
        raise CryptoError("El archivo no contiene HMAC de verificación.")
    header_without_mac = dict(header)
    header_without_mac.pop("hmac", None)
    real = _make_mac(password, header_without_mac, ciphertext)
    if not hmac.compare_digest(expected, real):
        raise CryptoError("Contraseña incorrecta o archivo cifrado dañado.")


def _pack(header: dict, ciphertext: bytes) -> bytes:
    header_bytes = json.dumps(header, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return MAGIC + struct.pack(">I", len(header_bytes)) + header_bytes + ciphertext


def _unpack(data: bytes) -> EncryptedPackage:
    if len(data) < len(MAGIC) + HEADER_LEN_SIZE or not data.startswith(MAGIC):
        raise CryptoError("El archivo no parece haber sido generado por esta aplicación.")
    offset = len(MAGIC)
    header_len = struct.unpack(">I", data[offset : offset + HEADER_LEN_SIZE])[0]
    offset += HEADER_LEN_SIZE
    header_bytes = data[offset : offset + header_len]
    ciphertext = data[offset + header_len :]
    try:
        header = json.loads(header_bytes.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise CryptoError("Encabezado del archivo cifrado inválido.") from exc
    return EncryptedPackage(header=header, ciphertext=ciphertext)


ALGORITHM_FILES: Dict[str, str] = {
    "AES": "aes",
    "DES": "des",
    "RC4": "rc4",
    "CESAR": "cesar",
    "VIGNERE": "vigenere",
}


def available_algorithms() -> Tuple[str, ...]:
    return tuple(ALGORITHM_FILES.keys())


def _safe_output_stem(name: str) -> str:
    name = (name or "").strip()
    if not name:
        return ""
    forbidden = '<>:"/\\|?*'
    for char in forbidden:
        name = name.replace(char, "_")
    return name.strip(" .")


def encrypt_file(
    input_path: str | Path,
    password: str,
    algorithm: str,
    output_dir: str | Path,
    output_name: str | None = None,
) -> Path:
    """Cifra cualquier archivo y devuelve la ruta del .encfile creado."""
    algorithm = algorithm.upper().strip()
    if algorithm not in ALGORITHM_FILES:
        raise CryptoError(f"Algoritmo no soportado: {algorithm}")

    input_path = Path(input_path)
    if not input_path.exists() or not input_path.is_file():
        raise CryptoError("El archivo seleccionado no existe.")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    data = input_path.read_bytes()
    encrypt_func = _load_function(ENCRYPTION_DIR, ALGORITHM_FILES[algorithm], "encrypt")
    algorithm_metadata, ciphertext = _call_algorithm(encrypt_func, data, password)

    header = {
        "algorithm": algorithm,
        "original_name": input_path.name,
        "original_suffix": input_path.suffix or ".bin",
        "file_type": "generic",
        "key_mode": KEY_MODE,
        **algorithm_metadata,
    }
    header["hmac"] = _make_mac(password, header, ciphertext)

    output_stem = _safe_output_stem(output_name) or f"{input_path.stem}_{algorithm}"
    output_path = output_dir / f"{output_stem}.encfile"
    counter = 1
    while output_path.exists():
        output_path = output_dir / f"{output_stem}_{counter}.encfile"
        counter += 1

    output_path.write_bytes(_pack(header, ciphertext))
    return output_path


def decrypt_file(input_path: str | Path, password: str, output_dir: str | Path) -> Path:
    """Descifra un archivo creado por la aplicación y recupera su extensión original."""
    input_path = Path(input_path)
    if not input_path.exists() or not input_path.is_file():
        raise CryptoError("El archivo cifrado seleccionado no existe.")

    package = _unpack(input_path.read_bytes())
    header = package.header
    algorithm = header.get("algorithm", "").upper()
    if algorithm not in ALGORITHM_FILES:
        raise CryptoError(f"Algoritmo del archivo no soportado: {algorithm}")

    _check_mac(password, header, package.ciphertext)
    decrypt_func = _load_function(DECRYPTION_DIR, ALGORITHM_FILES[algorithm], "decrypt")
    plain = _call_algorithm(decrypt_func, package.ciphertext, password, header)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    original_name = Path(header.get("original_name", "archivo_descifrado"))
    suffix = header.get("original_suffix") or original_name.suffix or ".bin"
    output_path = output_dir / f"{original_name.stem}_descifrado{suffix}"
    counter = 1
    while output_path.exists():
        output_path = output_dir / f"{original_name.stem}_descifrado_{counter}{suffix}"
        counter += 1

    output_path.write_bytes(plain)
    return output_path


# Compatibilidad con versiones anteriores del proyecto.
def encrypt_image_file(input_path: str | Path, password: str, algorithm: str, output_dir: str | Path) -> Path:
    return encrypt_file(input_path, password, algorithm, output_dir)


def decrypt_image_file(input_path: str | Path, password: str, output_dir: str | Path) -> Path:
    return decrypt_file(input_path, password, output_dir)

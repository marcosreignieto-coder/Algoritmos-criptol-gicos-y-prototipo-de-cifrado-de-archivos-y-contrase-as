"""Cifrado Vigenère clásico sobre bytes.

La contraseña se repite directamente: key[i % len(key)].
"""


def _key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave Vigenère no puede estar vacía.")
    return password.encode("utf-8")


def encrypt(data: bytes, password: str):
    key = _key(password)
    out = bytearray()
    for i, byte in enumerate(data):
        out.append((byte + key[i % len(key)]) % 256)
    metadata = {"key_length": len(key), "key_mode": "password_repetida"}
    return metadata, bytes(out)

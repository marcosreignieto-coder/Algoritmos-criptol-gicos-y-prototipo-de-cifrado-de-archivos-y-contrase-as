"""Cifrado AES-128 tradicional con clave directa de 16 bytes.

La contraseña se recorta o rellena con ceros hasta 16 bytes.
"""

import os
from base64 import b64encode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad


def _normalize_key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave AES no puede estar vacía.")
    raw = password.encode("utf-8")
    return raw[:16] if len(raw) >= 16 else raw + b"\x00" * (16 - len(raw))


def encrypt(data: bytes, password: str):
    key = _normalize_key(password)
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv=iv)
    ciphertext = cipher.encrypt(pad(data, AES.block_size))
    metadata = {"iv": b64encode(iv).decode("ascii"), "mode": "CBC", "key_size": 128, "key_mode": "clave_directa_16_bytes"}
    return metadata, ciphertext

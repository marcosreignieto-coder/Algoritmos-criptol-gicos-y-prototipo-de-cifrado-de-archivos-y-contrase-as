"""Cifrado DES tradicional con clave directa de 8 bytes.

La contraseña se recorta o rellena con ceros hasta 8 bytes.
"""

import os
from base64 import b64encode
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad


def _normalize_key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave DES no puede estar vacía.")
    raw = password.encode("utf-8")
    return raw[:8] if len(raw) >= 8 else raw + b"\x00" * (8 - len(raw))


def encrypt(data: bytes, password: str):
    key = _normalize_key(password)
    iv = os.urandom(8)
    cipher = DES.new(key, DES.MODE_CBC, iv=iv)
    ciphertext = cipher.encrypt(pad(data, DES.block_size))
    metadata = {"iv": b64encode(iv).decode("ascii"), "mode": "CBC", "key_mode": "clave_directa_8_bytes"}
    return metadata, ciphertext

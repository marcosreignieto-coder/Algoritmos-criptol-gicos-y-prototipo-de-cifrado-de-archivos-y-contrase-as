"""Cifrado RC4 clásico con clave directa."""


def _key(password: str) -> bytes:
    if password is None or password == "":
        raise ValueError("La clave RC4 no puede estar vacía.")
    return password.encode("utf-8")


def _keystream(key: bytes):
    s = list(range(256))
    j = 0
    for i in range(256):
        j = (j + s[i] + key[i % len(key)]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    while True:
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        yield s[(s[i] + s[j]) % 256]


def _apply(data: bytes, key: bytes) -> bytes:
    stream = _keystream(key)
    return bytes(byte ^ next(stream) for byte in data)


def encrypt(data: bytes, password: str):
    key = _key(password)
    return {"key_mode": "password_directa"}, _apply(data, key)

"""Cifrado César clásico sobre bytes.

Usa un desplazamiento numérico entre 0 y 255.
"""


def _caesar_shift(password: str) -> int:
    text = (password or "").strip()
    if not text:
        raise ValueError("Para César introduce un desplazamiento entre 0 y 255.")
    try:
        shift = int(text)
    except ValueError as exc:
        raise ValueError("Para César la contraseña debe ser un número entre 0 y 255.") from exc
    if not 0 <= shift <= 255:
        raise ValueError("El desplazamiento César debe estar entre 0 y 255.")
    return shift


def encrypt(data: bytes, password: str):
    shift = _caesar_shift(password)
    ciphertext = bytes((byte + shift) % 256 for byte in data)
    metadata = {"shift": shift, "key_mode": "desplazamiento_directo"}
    return metadata, ciphertext

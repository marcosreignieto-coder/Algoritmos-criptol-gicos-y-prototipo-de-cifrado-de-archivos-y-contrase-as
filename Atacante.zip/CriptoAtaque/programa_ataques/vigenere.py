"""Ataques contra Vigenère.

Primera versión sencilla: ataque por cabecera PNG.
Se asume una clave Vigenère periódica de hasta 16 bytes. La cabecera PNG conocida
permite reconstruir esos bytes y después se comprueba que el archivo recuperado no
esté corrupto validando la estructura PNG completa.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional

from .file_format import AttackError, unpack_encrypted_file
from .password_info import classify_password
from .png_utils import PNG_SIGNATURE, is_valid_png, safe_filename_part, unique_path
from .stats import AttackResult, AttackStats

ProgressCallback = Optional[Callable[[AttackStats, str], None]]
StopCallback = Optional[Callable[[], bool]]

# Los primeros 16 bytes de cualquier PNG válido:
# firma PNG + longitud del chunk IHDR + texto "IHDR".
PNG_KNOWN_HEADER_16 = PNG_SIGNATURE + b"\x00\x00\x00\rIHDR"


def decrypt_with_key(ciphertext: bytes, key: bytes) -> bytes:
    return bytes((byte - key[i % len(key)]) % 256 for i, byte in enumerate(ciphertext))


def key_to_text(key: bytes) -> str:
    try:
        text = key.decode("utf-8")
        if text and all((ch.isprintable() and ch not in "\r\n\t") for ch in text):
            return text
    except UnicodeDecodeError:
        pass
    return key.hex()


def _build_output_path(encrypted_path: str | Path, output_dir: str | Path, password_or_key: str) -> Path:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = safe_filename_part(Path(encrypted_path).stem)
    safe_key = safe_filename_part(password_or_key)
    return unique_path(output_dir / f"{stem} (contraseña {safe_key}).png")


def header_png(
    encrypted_path: str | Path,
    output_dir: str | Path,
    max_key_len: int = 16,
    progress_callback: ProgressCallback = None,
    stop_callback: StopCallback = None,
    max_iterations: int | None = None,
) -> AttackResult:
    """Reconstruye claves Vigenère de longitud 1..16 usando la cabecera PNG."""
    package = unpack_encrypted_file(encrypted_path)
    algorithm = package.header.get("algorithm", "").upper().strip()
    if algorithm != "VIGNERE":
        raise AttackError(f"Este ataque es para VIGNERE. El archivo indica: {algorithm or 'desconocido'}")

    if len(package.ciphertext) < len(PNG_KNOWN_HEADER_16):
        raise AttackError("El archivo cifrado es demasiado pequeño para aplicar ataque por cabecera PNG.")

    stats = AttackStats()
    start = time.perf_counter()
    last_tick = start
    last_count = 0

    effective_max_key_len = max_key_len
    if max_iterations is not None:
        effective_max_key_len = min(effective_max_key_len, max_iterations)

    for key_len in range(1, effective_max_key_len + 1):
        if stop_callback and stop_callback():
            stats.elapsed = time.perf_counter() - start
            return AttackResult(False, None, "VIGNERE", "cabecera PNG", None, stats, "Ataque detenido por el usuario.")

        # Como conocemos 16 bytes del PNG, podemos recuperar claves de hasta 16 bytes.
        key = bytes((package.ciphertext[i] - PNG_KNOWN_HEADER_16[i]) % 256 for i in range(key_len))
        plain = decrypt_with_key(package.ciphertext, key)

        stats.total_tests += 1
        now = time.perf_counter()
        interval = max(now - last_tick, 1e-9)
        current_rate = (stats.total_tests - last_count) / interval
        stats.elapsed = now - start
        stats.current_rate = current_rate
        stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
        if current_rate > 0:
            stats.min_rate = current_rate if stats.min_rate == 0 else min(stats.min_rate, current_rate)
            stats.max_rate = max(stats.max_rate, current_rate)
        last_tick = now
        last_count = stats.total_tests

        candidate = key_to_text(key)
        if progress_callback:
            progress_callback(stats, f"longitud {key_len} · clave {candidate}")

        if is_valid_png(plain):
            output_path = _build_output_path(encrypted_path, output_dir, candidate)
            output_path.write_bytes(plain)
            stats.elapsed = time.perf_counter() - start
            stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
            return AttackResult(
                True,
                output_path,
                "VIGNERE",
                "cabecera PNG",
                candidate,
                stats,
                f"PNG recuperado correctamente. Contraseña/clave Vigenère encontrada: {candidate}",
                password_length=len(candidate),
                password_type=classify_password(candidate),
            )

    stats.elapsed = time.perf_counter() - start
    stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
    return AttackResult(
        False,
        None,
        "VIGNERE",
        "cabecera PNG",
        None,
        stats,
        "No se encontró un PNG válido con claves Vigenère de longitud 1 a 16.",
    )

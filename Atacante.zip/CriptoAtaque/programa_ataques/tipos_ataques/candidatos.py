"""Generadores de contraseñas candidatas para ataques por contraseña.

VERSION_COMPARTIDA_GENERADOR = 20260520

Diccionario mediante librerías, centrado en español.

Fuentes principales:
- ``wordfreq``: palabras frecuentes SOLO en español.
- ``Faker`` con locale ``es_ES``: nombres, apellidos y combinaciones nombre+apellido.

La app NO guarda un diccionario pequeño cerrado. Genera muchos candidatos en tiempo
real a partir de corpus/librerías y aplica mutaciones humanas típicas: años,
números, mayúsculas, sin tildes, leet básico, separadores, etc.
"""

from __future__ import annotations

import itertools
import random
import unicodedata
from pathlib import Path
from typing import Iterable, Iterator

from ..config import (
    FAKER_FULLNAME_SAMPLES,
    FAKER_LOCALE,
    FAKER_NAME_SAMPLES,
    FAKER_SURNAME_SAMPLES,
    INTELLIGENT_NAME_LIMIT,
    INTELLIGENT_PAIR_LIMIT,
    INTELLIGENT_SPECIAL_CHARS,
    INTELLIGENT_SURNAME_LIMIT,
    INTELLIGENT_YEAR_CENTER,
    INTELLIGENT_YEAR_RADIUS,
    LIBRARY_LANGUAGES,
    LIBRARY_MUTATION_WORDS_PER_LANGUAGE,
    LIBRARY_WORDS_PER_LANGUAGE,
    MAX_CANDIDATE_LENGTH,
    NAME_YEAR_MUTATION_LIMIT,
    SHORT_YEAR_END,
    SHORT_YEAR_START,
    YEAR_END,
    YEAR_START,
    UNIQUE_CACHE_LIMIT,
)

BASE_DIR = Path(__file__).resolve().parents[1]
DEFAULT_DICTIONARY = BASE_DIR / "diccionarios" / "diccionario_base.txt"

COMMON_SUFFIXES = (
    "", "1", "2", "3", "12", "123", "1234", "12345", "123456", "0", "01", "007",
    "!", "?", ".", "_", "-", "@", "#", "*",
    "2023", "2024", "2025", "2026", "23", "24", "25", "26",
)
COMMON_PREFIXES = ("", "1", "123", "!", "@", "#")
SEPARATORS = ("", "_", "-", ".")

LEET_TABLE = str.maketrans({
    "a": "4", "e": "3", "i": "1", "o": "0", "s": "5", "t": "7",
    "A": "4", "E": "3", "I": "1", "O": "0", "S": "5", "T": "7",
})

# Pequeña lista de contexto. No es el diccionario principal; solo prioriza claves
# probables del proyecto antes de recorrer corpus grandes.
PROJECT_CONTEXT_WORDS = (
    "marco", "maria", "juan", "jose", "ana", "lucia", "pablo", "david", "daniel", "carlos", "alvaro", "javier",
    "garcia", "rodriguez", "gonzalez", "fernandez", "lopez", "martinez", "sanchez", "perez", "gomez", "martin",
    "aes", "des", "rc4", "cesar", "caesar", "vigenere", "vignere", "limon", "mianotuya", "mianotuy",
    "cripto", "criptologia", "proyecto", "proyecto2", "proyectoii", "imagen", "imagenes", "png", "archivo",
    "matematicas", "ingenieria", "universidad", "ceu", "sanpablo", "clave", "secreto", "contrasena", "contraseña",
)

PHRASE_LEFT = (
    "mi", "mia", "mio", "mis", "tu", "tus", "tuya", "tuyo", "soy", "hola", "clave", "contra", "secreto",
)
PHRASE_MIDDLE = ("", "no", "si", "es", "de", "del", "para", "por", "con", "sin", "y")
PHRASE_RIGHT = (
    "mia", "mio", "tuya", "tuyo", "suya", "suyo", "clave", "secreto", "contra", "cripto", "imagen", "png", "proyecto", "ceu",
)

KEYBOARD_PATTERNS = (
    "qwerty", "qwertyui", "qwertyuiop", "asdf", "asdfgh", "zxcv", "zxcvbn", "1q2w3e", "1qaz2wsx", "123qwe",
    "098765", "987654", "112233", "121212", "123123", "000000", "111111", "222222", "abcabc", "abcd", "abcdef",
)


def strip_accents(text: str) -> str:
    normalized = unicodedata.normalize("NFKD", text)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def normalize_candidate(text: str) -> str:
    return str(text).strip()


def valid_candidate(text: str) -> bool:
    return 0 < len(text) <= MAX_CANDIDATE_LENGTH and "\x00" not in text


def unique(iterable: Iterable[str]) -> Iterator[str]:
    """Deduplica candidatos sin crecimiento ilimitado de memoria.

    Las versiones anteriores mantenian todos los candidatos vistos durante toda
    la ejecucion. En ataques largos de millones de pruebas eso podia consumir
    mucha RAM y hacer que Windows cerrase o congelase la aplicacion.

    Aqui se mantiene una ventana de deduplicacion suficientemente grande para
    evitar repeticiones cercanas, pero se limpia periodicamente para que el
    consumo de memoria sea estable durante ejecuciones de muchas horas.
    """
    seen: set[str] = set()
    for item in iterable:
        candidate = normalize_candidate(item)
        if not valid_candidate(candidate) or candidate in seen:
            continue
        seen.add(candidate)
        if len(seen) > UNIQUE_CACHE_LIMIT:
            seen.clear()
        yield candidate


def read_dictionary(path: str | Path | None = None) -> Iterator[str]:
    dictionary_path = Path(path) if path else DEFAULT_DICTIONARY
    if not dictionary_path.exists():
        return
    with dictionary_path.open("r", encoding="utf-8", errors="ignore") as file:
        for line in file:
            word = line.strip()
            if word and not word.startswith("#"):
                yield word


def years() -> Iterator[str]:
    for year in range(YEAR_START, YEAR_END + 1):
        yield str(year)
    # 50..99 y 00..30 como años cortos típicos.
    for yy in range(SHORT_YEAR_START, 100):
        yield f"{yy:02d}"
    for yy in range(0, SHORT_YEAR_END + 1):
        yield f"{yy:02d}"


def wordfreq_words(
    languages: Iterable[str] = LIBRARY_LANGUAGES,
    words_per_language: int = LIBRARY_WORDS_PER_LANGUAGE,
) -> Iterator[str]:
    """Palabras frecuentes generadas por wordfreq, solo en español por config."""
    try:
        from wordfreq import top_n_list
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "Falta la librería 'wordfreq'. Instala dependencias con: py -m pip install -r requirements.txt"
        ) from exc

    for language in languages:
        for word in top_n_list(language, words_per_language):
            word = str(word).strip()
            if valid_candidate(word):
                yield word
                no_accents = strip_accents(word)
                if no_accents != word and valid_candidate(no_accents):
                    yield no_accents


def faker_spanish_people() -> Iterator[str]:
    """Genera nombres/apellidos españoles usando Faker es_ES.

    Es determinista para que las pruebas sean reproducibles. Aunque Faker genere
    muestras, internamente usa sus proveedores de nombres/apellidos españoles,
    por lo que cubre muchos candidatos sin guardar un TXT gigante.
    """
    try:
        from faker import Faker
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "Falta la librería 'Faker'. Instala dependencias con: py -m pip install -r requirements.txt"
        ) from exc

    Faker.seed(20260519)
    fake = Faker(FAKER_LOCALE)
    random.seed(20260519)

    for _ in range(FAKER_NAME_SAMPLES):
        yield fake.first_name()
    for _ in range(FAKER_SURNAME_SAMPLES):
        yield fake.last_name()
    for _ in range(FAKER_FULLNAME_SAMPLES):
        name = fake.first_name()
        surname = fake.last_name()
        yield name
        yield surname
        yield f"{name}{surname}"
        yield f"{name}.{surname}"
        yield f"{name}_{surname}"
        yield f"{name}-{surname}"
        if name and surname:
            yield f"{name[0]}{surname}"
            yield f"{name}{surname[0]}"


def spanish_name_base() -> Iterator[str]:
    """Base de candidatos centrados en nombres, apellidos y años."""
    yield from PROJECT_CONTEXT_WORDS
    yield from faker_spanish_people()


def wordfreq_mutation_base() -> Iterator[str]:
    yield from wordfreq_words(LIBRARY_LANGUAGES, LIBRARY_MUTATION_WORDS_PER_LANGUAGE)


def recurrent_passwords() -> Iterator[str]:
    words = [
        "1234", "12345", "123456", "1234567", "12345678", "123456789",
        "0000", "00000", "000000", "00000000", "1111", "111111", "11111111",
        "contraseña", "contrasena", "clave", "admin", "qwerty", "abc123",
        "test", "prueba", "demo", "usuario", "root", "toor",
        "cripto", "criptologia", "proyecto", "proyecto2", "proyectoii",
        "imagen", "imagenes", "png", "secreto", "ceu", "sanpablo",
        "mianotuya", "mianotuy", "marco", "matematicas", "ingenieria",
        "aes", "des", "rc4", "vigenere", "cesar", "hola", "holamundo", "limon", "ataque", "cifrado", "descifrado",
    ]
    yield from unique(words)


def project_context_words() -> Iterator[str]:
    yield from PROJECT_CONTEXT_WORDS
    yield from KEYBOARD_PATTERNS


def word_variants(word: str) -> Iterator[str]:
    no_accents = strip_accents(word)
    variants = [
        word,
        no_accents,
        word.lower(),
        no_accents.lower(),
        word.upper(),
        word.capitalize(),
        no_accents.capitalize(),
        word[::-1],
        no_accents[::-1],
        no_accents.translate(LEET_TABLE),
    ]
    yield from unique(variants)


def mutate_word(word: str) -> Iterator[str]:
    for base in word_variants(word):
        yield base
        for suffix in COMMON_SUFFIXES:
            if suffix:
                yield base + suffix
        for prefix in COMMON_PREFIXES:
            if prefix:
                yield prefix + base
        if len(base) <= 12:
            yield base + base


def mutate_with_years(word: str) -> Iterator[str]:
    """Mutaciones específicas para nombres/apellidos con años."""
    for base in word_variants(word):
        yield base
        for year in years():
            yield base + year
            yield year + base
        for sep in ("_", "-", "."):
            for year in years():
                yield f"{base}{sep}{year}"
                yield f"{year}{sep}{base}"


def phrase_candidates() -> Iterator[str]:
    for left in PHRASE_LEFT:
        for middle in PHRASE_MIDDLE:
            for right in PHRASE_RIGHT:
                parts = [part for part in (left, middle, right) if part]
                if len(parts) < 2:
                    continue
                for sep in SEPARATORS:
                    yield sep.join(parts)

    context = tuple(unique(itertools.chain(PROJECT_CONTEXT_WORDS, KEYBOARD_PATTERNS)))
    for left in context:
        for right in context:
            if left == right and len(left) > 3:
                continue
            for sep in SEPARATORS:
                yield f"{left}{sep}{right}"


def dictionary_candidates(dictionary_path: str | Path | None = None, mutate: bool = True) -> Iterator[str]:
    """Candidatos de diccionario con librerías, centrado en español.

    Orden de prueba:
    1. claves recurrentes;
    2. diccionario externo/local del usuario;
    3. nombres, apellidos y nombre+apellido con Faker es_ES;
    4. mutaciones con años sobre nombres/apellidos;
    5. palabras frecuentes en español con wordfreq;
    6. mutaciones sobre palabras frecuentes españolas;
    7. frases/patrones humanos.
    """
    user_words = tuple(unique(itertools.chain(read_dictionary(dictionary_path), read_dictionary(DEFAULT_DICTIONARY))))

    if not mutate:
        yield from unique(itertools.chain(recurrent_passwords(), user_words, spanish_name_base(), wordfreq_words(), project_context_words()))
        return

    def expanded() -> Iterator[str]:
        yield from recurrent_passwords()
        yield from user_words
        yield from contextual_compound_candidates()
        # Patrones rapidos de palabras de contexto + anos/simbolos para que el
        # diccionario no tarde en probar claves humanas habituales.
        priority_years = tuple(prioritized_years())
        for word in itertools.chain(user_words, PROJECT_CONTEXT_WORDS, PHRASE_LEFT, PHRASE_RIGHT):
            for base in word_variants(word):
                for year in priority_years:
                    yield base + year
                    yield year + base
                    for symbol in INTELLIGENT_SPECIAL_CHARS[:4]:
                        yield f"{base}{symbol}{year}"
                        yield f"{year}{symbol}{base}"

        # Prioridad: nombres/apellidos españoles. Se prueban muchos nombres en forma
        # directa, pero solo se mutan con años los primeros más probables/generados
        # para no crear decenas de millones de pruebas.
        people = tuple(unique(spanish_name_base()))
        yield from people
        people_for_years = people[:NAME_YEAR_MUTATION_LIMIT]
        for word in itertools.chain(user_words, people_for_years):
            yield from mutate_with_years(word)

        # Después, palabras frecuentes españolas.
        yield from wordfreq_words()
        yield from project_context_words()

        for word in itertools.chain(user_words, project_context_words(), wordfreq_mutation_base()):
            yield from mutate_word(word)

        for phrase in phrase_candidates():
            yield phrase
            yield strip_accents(phrase)
            yield phrase.capitalize()
            for suffix in ("1", "123", "2025", "2026", "!"):
                yield phrase + suffix

    yield from unique(expanded())


def brute_force_candidates(charset: str, min_len: int, max_len: int) -> Iterator[str]:
    for length in range(min_len, max_len + 1):
        for combo in itertools.product(charset, repeat=length):
            yield "".join(combo)


def numeric_candidates(max_len: int = 6) -> Iterator[str]:
    yield from brute_force_candidates("0123456789", 1, max_len)


def lowercase_candidates(max_len: int = 4) -> Iterator[str]:
    # Para fuerza bruta pura mantenemos letras sin ñ para no disparar combinaciones.
    yield from brute_force_candidates("abcdefghijklmnopqrstuvwxyz", 1, max_len)



def prioritized_years(center: int = INTELLIGENT_YEAR_CENTER, radius: int = INTELLIGENT_YEAR_RADIUS) -> Iterator[str]:
    """Años ordenados de forma determinista por cercanía a la época actual.

    Ejemplo de prioridad: 2026, 2025, 2027, 2024, 2028...
    Después añade los años cortos en el mismo orden: 26, 25, 27, 24, 28...

    Es importante no usar el orden de un ``set`` para que la app de ataques y
    el estimador recorran exactamente los mismos candidatos.
    """
    emitted: set[str] = set()
    ordered_full_years: list[str] = []
    for distance in range(0, radius + 1):
        for year in (center - distance, center + distance):
            full = str(year)
            if YEAR_START <= year <= YEAR_END and full not in emitted:
                emitted.add(full)
                ordered_full_years.append(full)
                yield full
    for full_year in ordered_full_years:
        yy = full_year[-2:]
        if yy not in emitted:
            emitted.add(yy)
            yield yy


def faker_name_lists() -> tuple[list[str], list[str], list[tuple[str, str]]]:
    """Devuelve nombres, apellidos y parejas nombre-apellido en español.

    Se limita el tamaño para que el ataque sea amplio pero razonable en Python.
    """
    try:
        from faker import Faker
    except Exception as exc:  # pragma: no cover
        raise RuntimeError(
            "Falta la librería 'Faker'. Instala dependencias con: py -m pip install -r requirements.txt"
        ) from exc

    Faker.seed(20260519)
    fake = Faker(FAKER_LOCALE)

    names: list[str] = []
    surnames: list[str] = []
    pairs: list[tuple[str, str]] = []
    seen_names: set[str] = set()
    seen_surnames: set[str] = set()
    seen_pairs: set[tuple[str, str]] = set()

    attempts = 0
    while (len(names) < INTELLIGENT_NAME_LIMIT or len(surnames) < INTELLIGENT_SURNAME_LIMIT or len(pairs) < INTELLIGENT_PAIR_LIMIT) and attempts < INTELLIGENT_PAIR_LIMIT * 4:
        attempts += 1
        name = strip_accents(str(fake.first_name()).strip()).lower()
        surname = strip_accents(str(fake.last_name()).strip().split()[0]).lower()
        if valid_candidate(name) and name not in seen_names and len(names) < INTELLIGENT_NAME_LIMIT:
            seen_names.add(name)
            names.append(name)
        if valid_candidate(surname) and surname not in seen_surnames and len(surnames) < INTELLIGENT_SURNAME_LIMIT:
            seen_surnames.add(surname)
            surnames.append(surname)
        pair = (name, surname)
        if name and surname and pair not in seen_pairs and len(pairs) < INTELLIGENT_PAIR_LIMIT:
            seen_pairs.add(pair)
            pairs.append(pair)
    return names, surnames, pairs


def _special_middle_variants(left: str, right: str) -> Iterator[str]:
    for symbol in INTELLIGENT_SPECIAL_CHARS:
        yield f"{left}{symbol}{right}"



def contextual_compound_candidates() -> Iterator[str]:
    """Combinaciones humanas cortas de palabras del contexto y palabras espanolas.

    Esto evita que el ataque inteligente dependa solo de palabras individuales.
    Por ejemplo, puede probar patrones como ``mi_tuya`` sin
    tener un diccionario de millones de claves ya escritas.
    """
    seeds = tuple(unique(itertools.chain(PROJECT_CONTEXT_WORDS, PHRASE_LEFT, PHRASE_RIGHT, KEYBOARD_PATTERNS)))
    for left in seeds:
        for right in seeds:
            if left == right:
                continue
            for sep in ("", "_", "-", ".", "!", "@"):
                yield f"{left}{sep}{right}"
    # Un bloque moderado de palabras frecuentes espanolas cortas para crear
    # compuestos humanos. Limitado para no convertirlo en una fuerza bruta enorme.
    try:
        frequent = []
        for word in wordfreq_words(words_per_language=15000):
            w = strip_accents(word).lower()
            if 2 <= len(w) <= 8 and w.isalpha():
                frequent.append(w)
            if len(frequent) >= 2500:
                break
        common_context = tuple(unique(itertools.chain(seeds, frequent[:250])))
        for left in common_context:
            for right in frequent[:600]:
                if left == right:
                    continue
                joined = f"{left}{right}"
                if valid_candidate(joined):
                    yield joined
    except Exception:
        return

def intelligent_attack_candidates(dictionary_path: str | Path | None = None) -> Iterator[str]:
    """Ataque inteligente basado en patrones humanos espanoles.

    Esta version empieza a devolver candidatos inmediatamente. Antes se
    preparaban listas grandes de Faker/wordfreq antes de la primera prueba, y
    con filtros estrictos parecia que la aplicacion estaba parada.
    """
    user_words = tuple(unique(itertools.chain(read_dictionary(dictionary_path), read_dictionary(DEFAULT_DICTIONARY))))
    priority_years = tuple(prioritized_years())

    def generated() -> Iterator[str]:
        # Candidatos instantaneos: hacen que las estadisticas se muevan desde el principio.
        yield from recurrent_passwords()
        yield from user_words
        yield from project_context_words()
        yield from contextual_compound_candidates()

        # Mutaciones baratas de palabras conocidas/externas.
        for word in itertools.chain(user_words, PROJECT_CONTEXT_WORDS, PHRASE_LEFT, PHRASE_RIGHT):
            yield from word_variants(word)
            for year in priority_years:
                for base in word_variants(word):
                    yield base + year
                    yield year + base
                    for symbol in INTELLIGENT_SPECIAL_CHARS[:4]:
                        yield f"{base}{symbol}{year}"
                        yield f"{year}{symbol}{base}"

        # Faker se calcula despues de haber enviado candidatos rapidos al motor.
        names, surnames, pairs = faker_name_lists()

        for word in itertools.chain(names, surnames):
            yield from word_variants(word)

        # Nombres/apellidos con anos cercanos a la epoca actual.
        for word in itertools.chain(names[:3000], surnames[:3000]):
            for base in word_variants(word):
                for year in priority_years:
                    yield base + year
                    yield year + base
                    for symbol in INTELLIGENT_SPECIAL_CHARS[:4]:
                        yield f"{base}{symbol}{year}"
                        yield f"{year}{symbol}{base}"

        # Parejas nombre + apellido, con separadores y simbolos en medio.
        for name, surname in pairs:
            for base_name in word_variants(name):
                for base_surname in word_variants(surname):
                    joined = f"{base_name}{base_surname}"
                    yield joined
                    yield from _special_middle_variants(base_name, base_surname)
                    for year in priority_years:
                        yield joined + year
                        yield f"{base_name}{base_surname}{year[-2:]}"
                        yield year + joined
                        for symbol in INTELLIGENT_SPECIAL_CHARS:
                            yield f"{base_name}{symbol}{base_surname}{year}"
                            yield f"{base_name}{symbol}{base_surname}{symbol}{year}"
                            yield f"{base_name}{base_surname}{symbol}{year}"
                            yield f"{base_name}{symbol}{year}{symbol}{base_surname}"

        # Palabras frecuentes espanolas y mutaciones, al final para ampliar cobertura.
        for word in itertools.chain(wordfreq_words(), wordfreq_mutation_base()):
            yield from mutate_word(word)

    yield from unique(generated())

def smart_candidates(dictionary_path: str | Path | None = None) -> Iterator[str]:
    """Ataque completo para contraseñas humanas en contexto español."""
    yield from unique(
        itertools.chain(
            recurrent_passwords(),
            contextual_compound_candidates(),
            intelligent_attack_candidates(dictionary_path),
            dictionary_candidates(dictionary_path, mutate=True),
            numeric_candidates(6),
            lowercase_candidates(4),
        )
    )

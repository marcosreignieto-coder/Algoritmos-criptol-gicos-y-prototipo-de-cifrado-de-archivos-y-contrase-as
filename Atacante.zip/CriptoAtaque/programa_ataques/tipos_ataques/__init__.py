"""Tipos de ataque disponibles en la app."""

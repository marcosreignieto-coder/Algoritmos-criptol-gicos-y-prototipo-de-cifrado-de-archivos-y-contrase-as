"""Motor común para ataques que prueban contraseñas.

Sirve para RC4, DES y AES en esta app didáctica. Primero comprueba el HMAC,
que es mucho más rápido que descifrar y validar cada candidato. Cuando el HMAC
coincide, descifra y valida que el resultado sea un PNG correcto.
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Iterable, Optional

from .. import aes, des, rc4
from ..auth_utils import build_password_output_path, password_matches_hmac
from ..file_format import AttackError, unpack_encrypted_file
from ..password_info import classify_password, password_type_matches
from ..png_utils import is_valid_png
from ..stats import AttackResult, AttackStats
from .parallel_utils import search_parallel

ProgressCallback = Optional[Callable[[AttackStats, str], None]]
StopCallback = Optional[Callable[[], bool]]


def _decrypt_for_algorithm(algorithm: str, ciphertext: bytes, password: str, header: dict) -> bytes:
    if algorithm == "RC4":
        return rc4.decrypt(ciphertext, password, header)
    if algorithm == "DES":
        return des.decrypt(ciphertext, password, header)
    if algorithm == "AES":
        return aes.decrypt(ciphertext, password, header)
    raise AttackError(f"Este ataque por contraseña solo está preparado para RC4, DES y AES. Detectado: {algorithm}")


def attack_password_candidates(
    encrypted_path: str | Path,
    output_dir: str | Path,
    candidates: Iterable[str],
    attack_type: str,
    progress_callback: ProgressCallback = None,
    stop_callback: StopCallback = None,
    min_password_len: int | None = None,
    max_password_len: int | None = None,
    password_type_filter: str | None = None,
    max_iterations: int | None = None,
) -> AttackResult:
    package = unpack_encrypted_file(encrypted_path)
    algorithm = package.header.get("algorithm", "").upper().strip()
    if algorithm not in {"RC4", "DES", "AES"}:
        raise AttackError(f"Este ataque es para RC4, DES o AES. El archivo indica: {algorithm or 'desconocido'}")

    min_len = min_password_len if min_password_len is not None else 1
    max_len = max_password_len

    def length_filtered(source: Iterable[str]) -> Iterable[str]:
        yielded = 0
        for candidate in source:
            if max_iterations is not None and yielded >= max_iterations:
                break
            if not candidate:
                continue
            size = len(candidate)
            if size < min_len:
                continue
            if max_len is not None and size > max_len:
                continue
            if not password_type_matches(candidate, password_type_filter):
                continue
            yielded += 1
            yield candidate

    def tester(password: str) -> Optional[tuple[str, bytes]]:
        if not password:
            return None
        if not password_matches_hmac(password, package):
            return None
        try:
            plain = _decrypt_for_algorithm(algorithm, package.ciphertext, password, package.header)
        except Exception:
            return None
        if is_valid_png(plain):
            return password, plain
        return None

    if progress_callback:
        progress_callback(AttackStats(), "Preparando candidatos...")

    found, stats, _last = search_parallel(
        length_filtered(candidates),
        tester,
        progress_callback=progress_callback,
        stop_callback=stop_callback,
        current_prefix="contraseña",
    )

    if stop_callback and stop_callback() and found is None:
        return AttackResult(False, None, algorithm, attack_type, None, stats, "Ataque detenido por el usuario o por límite de tiempo.")

    if found is None:
        rango = f" de longitud {min_len}" if max_len == min_len else f" de longitud entre {min_len} y {max_len}" if max_len is not None else f" de longitud mínima {min_len}"
        tipo = "" if not password_type_filter or password_type_filter == "Cualquiera" else f" y tipo {password_type_filter}"
        return AttackResult(False, None, algorithm, attack_type, None, stats, f"No se encontró ninguna contraseña válida para {algorithm}{rango}{tipo}.")

    password, plain = found
    output_path = build_password_output_path(encrypted_path, output_dir, password)
    output_path.write_bytes(plain)
    return AttackResult(
        True,
        output_path,
        algorithm,
        attack_type,
        password,
        stats,
        f"PNG recuperado correctamente. Contraseña encontrada: {password}",
        password_length=len(password),
        password_type=classify_password(password),
    )

"""Descifrado DES usado por la app de ataques.

Compatible con el DES CBC tradicional de la Cripto App didáctica.
"""

from __future__ import annotations

from base64 import b64decode
from Crypto.Cipher import DES
from Crypto.Util.Padding import unpad


def normalize_key(password: str) -> bytes:
    raw = password.encode("utf-8")
    return raw[:8] if len(raw) >= 8 else raw + b"\x00" * (8 - len(raw))


def decrypt(ciphertext: bytes, password: str, header: dict) -> bytes:
    key = normalize_key(password)
    iv = b64decode(header["iv"].encode("ascii"))
    cipher = DES.new(key, DES.MODE_CBC, iv=iv)
    return unpad(cipher.decrypt(ciphertext), DES.block_size)

"""Ataques contra César.

Aquí se recopilan las formas de descifrado de César:
- fuerza bruta por desplazamiento, probando los 256 valores posibles;
- ataque por cabecera PNG, calculando el desplazamiento desde la firma PNG.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Callable, Optional

from .file_format import AttackError, unpack_encrypted_file
from .png_utils import PNG_SIGNATURE, is_valid_png, safe_filename_part, unique_path
from .stats import AttackResult, AttackStats

ProgressCallback = Optional[Callable[[AttackStats, str], None]]
StopCallback = Optional[Callable[[], bool]]


def decrypt_with_shift(ciphertext: bytes, shift: int) -> bytes:
    return bytes((byte - shift) % 256 for byte in ciphertext)


def _build_output_path(encrypted_path: str | Path, output_dir: str | Path, shift: int) -> Path:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    stem = safe_filename_part(Path(encrypted_path).stem)
    return unique_path(output_dir / f"{stem} (desplazamiento {shift}).png")


def _update_stats(stats: AttackStats, start: float, last_tick: float, last_count: int) -> tuple[float, int]:
    now = time.perf_counter()
    interval = max(now - last_tick, 1e-9)
    current_rate = (stats.total_tests - last_count) / interval
    stats.elapsed = now - start
    stats.current_rate = current_rate
    stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
    if current_rate > 0:
        stats.min_rate = current_rate if stats.min_rate == 0 else min(stats.min_rate, current_rate)
        stats.max_rate = max(stats.max_rate, current_rate)
    return now, stats.total_tests


def brute_force_png(
    encrypted_path: str | Path,
    output_dir: str | Path,
    progress_callback: ProgressCallback = None,
    stop_callback: StopCallback = None,
    max_iterations: int | None = None,
) -> AttackResult:
    """Prueba los 256 desplazamientos y valida que el resultado sea PNG."""
    package = unpack_encrypted_file(encrypted_path)
    algorithm = package.header.get("algorithm", "").upper().strip()
    if algorithm != "CESAR":
        raise AttackError(f"Este ataque es para CESAR. El archivo indica: {algorithm or 'desconocido'}")

    stats = AttackStats()
    start = time.perf_counter()
    last_tick = start
    last_count = 0

    for shift in range(256):
        if max_iterations is not None and stats.total_tests >= max_iterations:
            stats.elapsed = time.perf_counter() - start
            return AttackResult(False, None, "CESAR", "fuerza bruta", None, stats, "Ataque detenido por límite de iteraciones.")
        if stop_callback and stop_callback():
            stats.elapsed = time.perf_counter() - start
            return AttackResult(False, None, "CESAR", "fuerza bruta", None, stats, "Ataque detenido por el usuario.")

        plain = decrypt_with_shift(package.ciphertext, shift)
        stats.total_tests += 1
        last_tick, last_count = _update_stats(stats, start, last_tick, last_count)
        if progress_callback:
            progress_callback(stats, f"desplazamiento {shift}")

        if is_valid_png(plain):
            output_path = _build_output_path(encrypted_path, output_dir, shift)
            output_path.write_bytes(plain)
            stats.elapsed = time.perf_counter() - start
            stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
            return AttackResult(
                True,
                output_path,
                "CESAR",
                "fuerza bruta",
                str(shift),
                stats,
                f"PNG recuperado correctamente con desplazamiento {shift}.",
            )

    stats.elapsed = time.perf_counter() - start
    stats.average_rate = stats.total_tests / max(stats.elapsed, 1e-9)
    return AttackResult(False, None, "CESAR", "fuerza bruta", None, stats, "No se encontró ningún PNG válido.")


def header_png(
    encrypted_path: str | Path,
    output_dir: str | Path,
    progress_callback: ProgressCallback = None,
    stop_callback: StopCallback = None,
    max_iterations: int | None = None,
) -> AttackResult:
    """Calcula el desplazamiento usando la primera posición de la cabecera PNG."""
    package = unpack_encrypted_file(encrypted_path)
    algorithm = package.header.get("algorithm", "").upper().strip()
    if algorithm != "CESAR":
        raise AttackError(f"Este ataque es para CESAR. El archivo indica: {algorithm or 'desconocido'}")

    stats = AttackStats()
    start = time.perf_counter()

    if stop_callback and stop_callback():
        return AttackResult(False, None, "CESAR", "cabecera PNG", None, stats, "Ataque detenido por el usuario.")

    if not package.ciphertext:
        raise AttackError("El archivo cifrado no contiene datos.")

    shift = (package.ciphertext[0] - PNG_SIGNATURE[0]) % 256
    plain = decrypt_with_shift(package.ciphertext, shift)
    stats.total_tests = 1
    stats.elapsed = time.perf_counter() - start
    stats.current_rate = 1 / max(stats.elapsed, 1e-9)
    stats.average_rate = stats.current_rate
    stats.min_rate = stats.current_rate
    stats.max_rate = stats.current_rate
    if progress_callback:
        progress_callback(stats, f"desplazamiento {shift}")

    if is_valid_png(plain):
        output_path = _build_output_path(encrypted_path, output_dir, shift)
        output_path.write_bytes(plain)
        return AttackResult(
            True,
            output_path,
            "CESAR",
            "cabecera PNG",
            str(shift),
            stats,
            f"PNG recuperado correctamente con desplazamiento {shift}.",
        )

    return AttackResult(
        False,
        None,
        "CESAR",
        "cabecera PNG",
        str(shift),
        stats,
        "El desplazamiento calculado por cabecera no genera un PNG válido.",
    )

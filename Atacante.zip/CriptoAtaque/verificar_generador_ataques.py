from pathlib import Path
import itertools
from programa_ataques.tipos_ataques.candidatos import intelligent_attack_candidates
from programa_ataques.password_info import password_type_matches

TARGET = "Nicolas2006"
count = 0
for cand in intelligent_attack_candidates(None):
    if 8 <= len(cand) <= 12 and password_type_matches(cand, "Alfanumérica"):
        count += 1
        if cand == TARGET:
            print(f"OK: {TARGET} aparece como candidato exacto en la posicion {count}.")
            break
        if count >= 1_000_000:
            raise SystemExit(f"NO ENCONTRADO: {TARGET} no aparece antes de 1.000.000 candidatos validos.")
else:
    raise SystemExit("NO ENCONTRADO: el generador termino antes de encontrar la clave.")
